# Cron setup correcto en Supabase

## Flujo recomendado

1. Deployar `review-automation` como Edge Function.
2. Cargar secrets de la funcion.
3. Probar la funcion manualmente.
4. Instalar `pg_net` desde SQL Editor.
5. Crear el cron desde `Integrations > Cron`.

## SQL previo

En Supabase SQL Editor ejecutar:

```sql
create extension if not exists pg_net;
```

Si Supabase pide instalar `pg_cron`, tambien ejecutar:

```sql
create extension if not exists pg_cron;
```

No usar `vault` si el proyecto no lo tiene disponible.

## Configuracion del job

En Supabase Dashboard:

- Ir a `Integrations`
- Entrar a `Cron`
- Crear job
- Nombre: `review-automation-nightly`
- Schedule de prueba: `* * * * *`
- Schedule real recomendado: `0 3 * * *`
- Type: `Supabase Edge Function`
- Method: `POST`
- Edge Function: `review-automation`
- Timeout: `60000 ms`
- Headers:
  - `Content-Type: application/json`
- Body:

```json
{"trigger":"nightly_cron"}
```

## Verificacion

Despues de guardar el job:

- revisar runs del cron
- revisar logs de la Edge Function
- revisar `review_check_runs`
- revisar `email_events`
- revisar `coupons`

Si el cron dura pocos milisegundos no necesariamente es error: el job puede estar disparando la request. Lo importante es que aparezca ejecucion en los logs de la Edge Function.
