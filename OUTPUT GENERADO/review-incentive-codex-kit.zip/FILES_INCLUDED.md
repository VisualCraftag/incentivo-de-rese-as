# Archivos incluidos en el zip

## Prompt de integracion

- `prompt/INTEGRATION_PROMPT.md`

## Landing publica

- `landing/package.json`
- `landing/package-lock.json`
- `landing/index.html`
- `landing/vite.config.js`
- `landing/vercel.json`
- `landing/.env.example`
- `landing/src/App.jsx`
- `landing/src/main.jsx`
- `landing/src/index.css`
- `landing/src/restaurant-config.js`
- `landing/src/lib/submissions.js`
- `landing/src/lib/supabase.js`
- `landing/src/lib/admin.js`
- `landing/public/logo-placeholder.svg`
- `landing/public/favicon.svg`
- `landing/public/icons.svg`

## Supabase

- `supabase/schema.sql`
- `supabase/config.toml`
- `supabase/functions/admin-coupons/index.ts`
- `supabase/functions/admin-coupons/README.md`
- `supabase/functions/review-automation/index.ts`
- `supabase/functions/review-automation/README.md`
- `supabase/review-automation-cron-reference.sql`

## Automatizacion local

- `automation/apify-review-checker/index.mjs`
- `automation/apify-review-checker/email-workflow.mjs`
- `automation/apify-review-checker/email-delivery.mjs`
- `automation/apify-review-checker/README.md`

## Variables de entorno

- `.env.server.example`
- `landing/.env.example`

## Guia complementaria

La guia operativa completa se entrega como documento Word separado:

- `Kit Incentivo Resenas.docx`
