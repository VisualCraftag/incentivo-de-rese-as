# Checklist paso a paso para replicar el sistema de incentivo de resenas

## 1. Preparar el proyecto

- Verificar que exista la carpeta `review-incentive-codex-kit`.
- Abrir `prompt/INTEGRATION_PROMPT.md`.
- Confirmar que la segunda linea indique que el kit esta dentro de `review-incentive-codex-kit`.
- Copiar el prompt completo y pegarlo en Codex dentro del proyecto destino.
- Pedir a Codex que adapte la landing al restaurante real.
- Recordar que el kit ya incluye un `/admin` para chequeo y canje de cupones.

## 2. Datos necesarios del restaurante

- Nombre comercial del restaurante.
- Logo en PNG, SVG o WebP.
- Paleta de colores.
- Link exacto de Google Maps con la seccion de resenas abierta.
- Numero de WhatsApp para soporte.
- Email de respuesta si el restaurante quiere recibir respuestas.

## 3. Crear Supabase

- Crear un proyecto nuevo en Supabase.
- Esperar a que termine la inicializacion.
- Ir a `Project Settings > API`.
- Guardar:
  - Project URL
  - anon/publishable key
  - service role key

## 4. Crear base de datos

- Abrir `SQL Editor`.
- Pegar el contenido de `supabase/schema.sql`.
- Ejecutar `RUN`.
- Verificar que existan:
  - `review_submissions`
  - `review_check_runs`
  - `matched_reviews`
  - `coupons`
  - `email_events`
- Confirmar que `coupons` tenga tambien la columna `redeemed_at`.

## 5. Configurar Resend

- Usar la cuenta de VisualCraft.
- Confirmar que el dominio `mail.visualcraftagency.com` este verificado.
- Crear una API key nueva para este cliente/restaurante.
- Guardar `RESEND_API_KEY`.
- Definir remitente:
  - `Restaurante <reviews@mail.visualcraftagency.com>`
- No usar `RESEND_TO_OVERRIDE` en produccion.

## 6. Crear Apify saved task

- Entrar a Apify.
- Abrir el actor `compass/google-maps-reviews-scraper`.
- Crear una saved task nueva por restaurante.
- Configurar:
  - Google Maps place URL: ficha exacta del restaurante
  - Sort reviews by: `Newest`
  - Only scrape reviews newer than: `Relative`
  - Relative value: `1`
  - Unit: `Days`
  - Language: `Espanol (Latinoamerica)` si aplica
  - Reviews origin: `All reviews`
- Guardar la task.
- Copiar el `APIFY_TASK_ID`.
- Generar o reutilizar `APIFY_TOKEN`.

## 7. Adaptar landing

- Editar `landing/src/restaurant-config.js`.
- Reemplazar:
  - `restaurantName`
  - `logoSrc`
  - `logoAlt`
  - `googleMapsReviewUrl`
  - textos si corresponde
- Editar colores en `landing/src/index.css`.
- Reemplazar `landing/public/logo-placeholder.svg` por el logo final.
- Confirmar que el CTA de resena conserve el fix de iPhone/Safari:
  - abrir pestana vacia antes del `await`
  - navegarla al link de Google Maps si Supabase guarda bien
  - cerrarla si el submit falla o el email esta duplicado
- Verificar tambien que `/admin` exista dentro de la misma SPA.
- Probar localmente:

```bash
npm install
npm run dev
```

## 8. Deploy en Vercel

- Crear repo GitHub para el restaurante.
- Subir el contenido de `landing/`.
- Importar el repo en Vercel.
- Framework: `Vite`.
- Build command: `npm run build`.
- Output directory: `dist`.
- Variables de Vercel:
  - `VITE_SUPABASE_URL`
  - `VITE_SUPABASE_ANON_KEY`
- Deployar.
- Probar que el formulario cree una fila en `review_submissions`.
- Probar tambien que `/admin` abra la SPA y no devuelva 404.

## 9. Deploy Edge Functions

- Linkear Supabase CLI:

```bash
npx supabase@latest login
npx supabase@latest link --project-ref PROJECT_REF
```

- Cargar secrets:

```bash
npx supabase@latest secrets set APIFY_TOKEN=...
npx supabase@latest secrets set APIFY_TASK_ID=...
npx supabase@latest secrets set APIFY_DATASET_LIMIT=200
npx supabase@latest secrets set RESEND_API_KEY=...
npx supabase@latest secrets set RESEND_FROM_EMAIL="Restaurante <reviews@mail.visualcraftagency.com>"
npx supabase@latest secrets set RESTAURANT_NAME="Nombre Restaurante"
npx supabase@latest secrets set WHATSAPP_URL="https://wa.me/54911XXXXXXXX"
npx supabase@latest secrets set ADMIN_PANEL_USERNAME="admin"
npx supabase@latest secrets set ADMIN_PANEL_PASSWORD="cambiar-por-password-segura"
npx supabase@latest secrets set ADMIN_PANEL_SESSION_SECRET="string-largo-y-unico"
```

- Deployar la function de admin, que necesita `verify_jwt = false` por config:

```bash
npx supabase@latest functions deploy admin-coupons --project-ref PROJECT_REF
```

- Deployar la function nocturna:

```bash
npx supabase@latest functions deploy review-automation --project-ref PROJECT_REF --no-verify-jwt
```

## 10. Probar admin de cupones

- Abrir `https://TU_DOMINIO/admin`.
- Ingresar `ADMIN_PANEL_USERNAME` y `ADMIN_PANEL_PASSWORD`.
- Buscar un cupon real ya generado.
- Confirmar que muestre:
  - codigo
  - status
  - nombre visible de Google Maps
  - mail
  - fechas relevantes
- Si el cupon esta en `generated` o `sent`, tocar `Marcar como canjeado`.
- Revisar en Supabase que:
  - `coupons.status = redeemed`
  - `coupons.redeemed_at` tenga timestamp

## 11. Probar funcion nocturna manualmente

- Ejecutar un POST manual a:

```text
https://PROJECT_REF.supabase.co/functions/v1/review-automation
```

- Verificar:
  - logs de Edge Function
  - `review_check_runs`
  - `review_submissions`
  - `email_events`
  - `coupons`

## 12. Crear cron correctamente

- En `SQL Editor`, instalar:

```sql
create extension if not exists pg_net;
```

- Si Supabase lo pide, instalar tambien:

```sql
create extension if not exists pg_cron;
```

- Ir a `Integrations > Cron`.
- Crear job:
  - Name: `review-automation-nightly`
  - Schedule test: `* * * * *`
  - Schedule real: `0 3 * * *`
  - Type: `Supabase Edge Function`
  - Method: `POST`
  - Edge Function: `review-automation`
  - Timeout: `60000 ms`
  - Header: `Content-Type: application/json`
  - Body: `{"trigger":"nightly_cron"}`

## 13. Verificacion final

- Crear una submission de prueba desde la landing.
- Publicar o simular una resena con el mismo nombre visible.
- Probar tambien un cupon desde `/admin`.
- Ejecutar el cron manual o esperar el minuto de prueba.
- Confirmar:
  - si encuentra match positivo, genera cupon y email
  - si no encuentra match, envia email de no encontrada
  - si encuentra 3 estrellas o menos, envia mail de soporte
  - submissions resueltas no se reprocesan
  - un cupon ya canjeado no puede volver a canjearse desde el panel

## Checklist rapida final

- Kit entregado a Codex.
- Landing adaptada.
- Supabase creado.
- SQL ejecutado.
- Resend API key creada.
- Apify saved task creada.
- Vercel deployado.
- Edge Function `review-automation` deployada.
- Edge Function `admin-coupons` deployada.
- Cron creado desde `Integrations > Cron`.
- Logs verificados.
- Emails reales probados.
