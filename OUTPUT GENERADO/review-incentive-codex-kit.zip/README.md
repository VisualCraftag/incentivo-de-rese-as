# Review Incentive Codex Kit

Este kit sirve para replicar el sistema de incentivo de resenas en Google Maps para otros restaurantes con ayuda de Codex.

## Que incluye

- `prompt/INTEGRATION_PROMPT.md`
- `landing/*`
- `supabase/schema.sql`
- `supabase/config.toml`
- `supabase/functions/review-automation/*`
- `supabase/functions/admin-coupons/*`
- `supabase/review-automation-cron-reference.sql`
- `automation/apify-review-checker/*`
- `.env.server.example`
- `FILES_INCLUDED.md`

## Que NO incluye

- `node_modules`
- `dist`
- `.env` real
- API keys reales
- tokens de Supabase, Resend o Apify
- logos finales del cliente

## Uso rapido

1. Crear una copia del proyecto o un repo nuevo para el restaurante.
2. Entregar este zip a Codex junto con `prompt/INTEGRATION_PROMPT.md`.
3. Pedirle a Codex que adapte:
   - nombre del restaurante
   - logo
   - colores
   - link de Google Maps para dejar resena
   - remitente y textos de email
4. Crear un proyecto Supabase nuevo.
5. Ejecutar `supabase/schema.sql`.
6. Crear una saved task de Apify usando el scraper de Google Maps Reviews.
7. Configurar Resend usando el dominio ya verificado de VisualCraft.
8. Deployar la landing en Vercel.
9. Deployar las Edge Functions en Supabase.
10. Crear el cron desde `Integrations > Cron`.
11. Probar `/admin` para validar y canjear cupones.

## Variables publicas de la landing

- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`

Estas variables van en Vercel.

## Variables server-side

- `SUPABASE_URL`
- `SUPABASE_SERVICE_ROLE_KEY`
- `APIFY_TOKEN`
- `APIFY_TASK_ID`
- `APIFY_DATASET_LIMIT`
- `RESEND_API_KEY`
- `RESEND_FROM_EMAIL`
- `RESEND_REPLY_TO`
- `RESEND_TO_OVERRIDE`
- `RESTAURANT_NAME`
- `WHATSAPP_URL`
- `ADMIN_PANEL_USERNAME`
- `ADMIN_PANEL_PASSWORD`
- `ADMIN_PANEL_SESSION_SECRET`

Estas variables van en Supabase Edge Function secrets o en local cuando se prueba el script.

## Admin incluido

La landing base ya trae un `/admin` para personal del local:

- login con usuario y contrasena fijos
- lookup de cupon por codigo
- cambio de estado a `redeemed`
- almacenamiento de `redeemed_at`

La UI del admin vive en la misma app Vite, pero la validacion sensible ocurre dentro de la Edge Function `admin-coupons`.

## Dependencias clave

Landing:

- `react`
- `react-dom`
- `vite`
- `@supabase/supabase-js`

Edge Functions:

- Supabase Edge Runtime
- `@supabase/supabase-js`
- Apify API
- Resend API

## Recomendacion practica

La landing esta pensada como una base Vite + React muy liviana. Si la web destino ya existe, Codex puede reutilizar la logica de captura y adaptar la UI al stack real.

Si el restaurante necesita una landing independiente por local, lo mas rapido es copiar `landing/`, adaptar `src/restaurant-config.js`, cambiar colores en `src/index.css`, y deployar en Vercel como proyecto separado.

## Nota Safari/iPhone

El CTA de resena debe abrir una pestana vacia de forma sincronica en el click y navegarla despues del `await` de Supabase. Safari bloquea `window.open()` si se ejecuta despues de una promesa. Si el submit falla o el email ya existe, la pestana temporal debe cerrarse.
