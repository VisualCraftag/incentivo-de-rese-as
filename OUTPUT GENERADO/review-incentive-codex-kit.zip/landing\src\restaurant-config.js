export const restaurantConfig = {
  restaurantName: 'NOMBRE_DEL_RESTAURANTE',
  logoSrc: '/logo-placeholder.svg',
  logoAlt: 'Logo del restaurante',
  googleMapsReviewUrl: 'PEGAR_LINK_DE_GOOGLE_MAPS_CON_REVIEW_TAB',
  localStorageKey: 'reviewSubmissionLock',
  eyebrow: 'Dejanos tu resena',
  description:
    'Dejanos una resena en Google Maps y recibi un cupon para tu proxima visita.',
  thankYouTitle: 'Gracias por tu tiempo',
  thankYouMessage: 'Gracias, revisa la pestana para dejar tu resena en Google Maps.',
  duplicateTitle: 'Solicitud registrada',
  duplicateMessage: 'Ya registramos una solicitud con este mail.',
  duplicateHelp:
    'Si crees que hubo un error, contactanos por el canal de soporte del restaurante.',
}
