Quiero replicar el sistema de incentivo de resenas de restaurante usando el kit adjunto.

pd: el kit esta adentro de la carpeta del proyecto en una carpeta llamada: review-incentive-codex-kit

## Contexto

- La landing debe capturar dos datos obligatorios:
  - nombre visible de Google Maps
  - email
- Al enviar el formulario, la submission se guarda en Supabase.
- Si Supabase acepta la submission, la landing abre una pestana nueva con el link exacto de Google Maps para dejar resena.
- La pagina queda mostrando un mensaje de gracias.
- El email no puede usarse dos veces.
- El match de resena se hace solo por nombre visible de Google Maps.
- El email se usa solo para enviar cupones o mensajes automaticos.
- La misma landing debe incluir `/admin` para validacion y canje de cupones.

## Objetivo

1. Adaptar la landing al restaurante nuevo.
2. Mantener la logica de Supabase, Apify, Resend, cupones y cron del kit.
3. Crear una experiencia visual que parezca propia del restaurante.
4. Dejar listo el deploy en Vercel.
5. Dejar documentados los pasos pendientes para Supabase, Apify, Resend y Cron.
6. Mantener operativo el panel `/admin`.

## Instrucciones

1. Analiza primero el repo destino antes de tocar codigo.
2. Detecta:
   - framework
   - estructura de rutas
   - sistema de estilos
   - manejo de variables de entorno
   - si ya existe Supabase
   - si ya existe Resend
   - si ya hay formularios o automatizaciones parecidas
3. Si el proyecto destino es nuevo o puede ser landing independiente, usa `landing/` como base principal.
4. Si el proyecto destino ya existe, adapta la logica del kit al stack real sin romper su diseno actual.
5. Integra o adapta estas piezas:
   - `landing/src/lib/submissions.js`
   - `landing/src/lib/admin.js`
   - `landing/src/lib/supabase.js`
   - `landing/src/restaurant-config.js`
   - `supabase/schema.sql`
   - `supabase/config.toml`
   - `supabase/functions/admin-coupons/*`
   - `supabase/functions/review-automation/*`
   - `automation/apify-review-checker/*` si se requiere prueba local
6. En `restaurant-config.js`, reemplaza:
   - `restaurantName`
   - `logoSrc`
   - `logoAlt`
   - `googleMapsReviewUrl`
   - textos visibles si corresponde
7. En `index.css`, adapta los tokens:
   - `--page-top`
   - `--page-bg`
   - `--brand-primary`
   - `--brand-secondary`
   - `--brand-glow`
   - `--text-main`
   - `--text-muted`
8. Si el cliente entrega logo, reemplaza `public/logo-placeholder.svg` por el logo real.
9. La landing debe conservar estos comportamientos:
   - formulario con dos campos obligatorios
   - insert en `review_submissions`
   - apertura compatible con iPhone/Safari: abrir una pestana vacia sincronica en el click y navegarla despues del await
   - cerrar esa pestana temporal si el submit falla o el email ya existe
   - estado de gracias
   - estado de email duplicado
   - localStorage lock como ayuda visual
   - ruta `/admin` con login interno
   - lookup de cupon por codigo
   - accion de marcar cupon como canjeado
10. No expongas en frontend:
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `APIFY_TOKEN`
   - `RESEND_API_KEY`
   - usuario/password admin reales
11. Las variables publicas de Vercel son solo:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
12. Las variables server-side van en Supabase Edge Function secrets:
   - `APIFY_TOKEN`
   - `APIFY_TASK_ID`
   - `APIFY_DATASET_LIMIT`
   - `RESEND_API_KEY`
   - `RESEND_FROM_EMAIL`
   - `RESEND_REPLY_TO`
   - `RESTAURANT_NAME`
   - `WHATSAPP_URL`
   - `ADMIN_PANEL_USERNAME`
   - `ADMIN_PANEL_PASSWORD`
   - `ADMIN_PANEL_SESSION_SECRET`
13. Usa Resend con el dominio verificado de VisualCraft, por ejemplo:
   - `Restaurante <reviews@mail.visualcraftagency.com>`
14. Crea o conserva la Edge Function `review-automation`.
15. El cron debe crearse desde Supabase Dashboard:
   - primero instalar `pg_net` en SQL Editor
   - luego ir a `Integrations > Cron`
   - crear job de tipo `Supabase Edge Function`
   - metodo `POST`
   - funcion `review-automation`
   - timeout recomendado `60000 ms`
   - body `{"trigger":"nightly_cron"}`

## Admin de cupones

- Mantener la UI en `/admin`.
- No validar admin en frontend con secretos hardcodeados.
- La validacion debe ocurrir en la Edge Function `admin-coupons`.
- `admin-coupons` necesita `verify_jwt = false` en `supabase/config.toml`.
- El navegador solo debe recibir un token de sesion corto firmado por la function.
- El panel debe permitir:
  - login
  - buscar cupon
  - ver nombre Google Maps y mail del submission
  - ver estado del cupon
  - marcarlo como `redeemed`
  - guardar `redeemed_at`

## Configuracion Apify esperada

Crear una saved task del actor:

`compass/google-maps-reviews-scraper`

Parametros:

- Google Maps place URL: link del restaurante exacto
- Sort reviews by: Newest
- Only scrape reviews newer than: Relative
- Relative value: 1
- Unit: Days
- Language: Spanish Latin America si aplica
- Reviews origin: All reviews

Guardar el `APIFY_TASK_ID` de la saved task y generar `APIFY_TOKEN`.

## Entregables

Al final devolve:

1. archivos creados o modificados
2. variables de entorno necesarias
3. pasos para correr SQL en Supabase
4. pasos para deployar landing en Vercel
5. pasos para deployar Edge Functions
6. pasos para crear cron en Supabase
7. pasos para probar:
   - formulario publico
   - admin de cupones
   - match por Apify
   - envio de cupon
   - mail de resena no encontrada
   - mail de baja calificacion
8. cualquier tradeoff tecnico relevante

## Criterio de calidad

- No mezclar implementaciones parciales.
- No duplicar logica de Supabase o email.
- Mantener secretos fuera del frontend.
- La landing debe verse nativa del restaurante.
- El workflow debe ser replicable por local/restaurante.
- Los estados finales deben evitar reprocesar submissions ya resueltas.
